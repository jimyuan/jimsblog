
#import <Foundation/Foundation.h>

NSString* discountToHTML(NSString *markdown);