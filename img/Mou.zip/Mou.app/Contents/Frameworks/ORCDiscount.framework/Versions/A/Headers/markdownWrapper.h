
#ifndef		_markdownWrapper_
#define		_markdownWrapper_

int mkd_compile_wrapper(Document *doc, int flags);
int mkd_document_wrapper(Document *p, char **res);

#endif	//	_markdownWrapper_